%Question Number 1
clc
close all
clear all
%A)
A=0.5*ones(128);
%B)
B=0.5*ones(128);
B(54:73, 54:73) = ones(20);
imshow(B)
% imshow(I,[])
%C)
C=0:1/127:1;
CC=nncopy(C,128,1)
imshow(CC)
%D)
% D=
%E)
n=-8*pi:(16*pi)/128:8*pi;
L=cos(n);
CS=nncopy(L,128,1)
imshow(CS)
%
% 
% F = fft2(I);
% Fc = fftshift(F)
% figure
% imshow(log(abs(Fc) + 0.0001))


%%
%Question Number 2
clc
close all
clear all
I=imread('cameraman.tif');
D0=20;
n=5;
cutoff=10;
f = BWLPfilter(image, cutoff, n)
figure
h = BWLPfilterh(image, cutoff, n)
%%
%Question Number 3
clc
close all
clear all
N=8;
N=16;
I = im2double(imread('rice.png'));
D = dctmtx(size(I,1));
dct = D*I*D';
figure, imshow(dct)