function C =  mydctmtx( N )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
[N,N]=size(I);
for k==0
    0<=n<=(N-1)
C(k,n)=sqrt(1/N)
end
for k==0
    0<=n<=(N-1)
    
C(k,n)=sqrt(2/N)*cos(pi(2*n+1)*k/(2*N))  
end

end

%