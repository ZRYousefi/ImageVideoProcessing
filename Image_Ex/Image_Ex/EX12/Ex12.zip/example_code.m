% example_code.m file
% draft file for SGN-12006 Exercise 12
% Juha Pajula,
% Tampere University of Technology, 
% Department of Signal Processing 

% read the filenames from the folder (or define them by hand):

	%insert used code here or...

	filename = 	%fill the path here


% reading the file header

    	%Close the file handle after this (fclose).
	fid = fopen(filename,'r');
	%reading data from the beginning of the file:
	datavector=fread(fid,100,'uint8');
	%closing the open file:
	fclose(fid);	

	%pre-processing the header
	headerline=char(datavector');
	keyword='FRAME';
	%searching where the frame data begins
	index=strfind(headerline,keyword);
	%read only the header
	header=headerline(1:index-2)
	

% process the header here:
% find W, H, F, I, A and C variables from header 


	%Use the code from exercise 11:
	%header variable here corresponds to the single string variable parameters(x).header in exercise 11



% read the image data for processing:

	%define cols and rows according to the header
	cols = 		%fill here
	rows = 		%fill here


	Nmax=50; 			%number of frames to read max
	fid = fopen(filename,'r'); 	%open the file
	keyword='FRAME';		%the frame tag to search for

	%computing the segment length:
	segmentlength = (rows*cols*1.5)+length(keyword)+1;

	%searching the first index
	firstindex=strfind(char(datavector)',keyword);
	
	%variable for locations, first column defines index number, second the location
	locations=[1 2];
	
	%searching the frame locations:
	for frameindex=1 : Nmax
	   location=(frameindex-1)*segmentlength+firstindex;
 	   locations=cat(1,locations,[frameindex location]); %collect the frame locations to 2 x Nmax vector
	end

	%the first location is false and thus left out
	locations=locations(2:end,:) 


	
	%reading the image data from frame 1
	frameindex=1;
	pointeroffset=locations(frameindex,2)+length(keyword);
	%moving the pointer to correct location:
	status=fseek(fid,pointeroffset,'bof');
	%read the frame data
	datavector=fread(fid,segmentlength-length(keyword)-1,'uint8');
	
	%check that the length is correct:
	length(datavector)+ length(keyword)+1
	segmentlength



% reading the frame components from the datavector:
	%where it starts	
	aa=1;
	bb=rows*cols;
	
	%reading the Y component
	yy=datavector(aa:bb);

	%where next component starts
	cc=length(yy)+1;
	dd=length(yy)+((rows/2)*(cols/2));

	%reading the U component
	uu=datavector(cc:dd);

	%where the last component starts
	ee=length(yy)+length(uu)+1;
	ff=length(yy)+length(uu)+((rows/2)*(cols/2));
	
	%reading the V component
	vv=datavector(ee:ff);

% construct image:
	

	%Use the code from Task I to costruct the image





